# Sprintly

App de défis vidéo communautaires : proposer un défi, participer avec un
lien vidéo, tirage au sort, duels, votes, trophées, Hall of Fame.

Les données sont stockées dans **Supabase** (une vraie base de données
Postgres en ligne), pas dans un stockage temporaire — donc ça marche une
fois le site déployé, pour de vrai, avec du monde.

---

## 1. Mettre en place la base de données (à faire une seule fois)

1. Va sur ton projet Supabase → **SQL Editor** (menu de gauche)
2. Clique **New query**
3. Ouvre le fichier `supabase/schema.sql` de ce projet, copie tout son
   contenu, colle-le dans l'éditeur, puis clique **Run**
4. Tu dois voir "Success. No rows returned" — la base est prête.

## 2. Créer ton compte administrateur

Le mot de passe admin codé en dur a été remplacé par un vrai compte.

1. Dans Supabase : **Authentication** → **Users** → **Add user** →
   **Create new user**
2. Renseigne un email et un mot de passe (ce sera tes identifiants pour
   `#/admin` sur le site)
3. Une fois créé, **copie son UUID** (colonne "User UID")
4. Retourne dans **SQL Editor**, et exécute (en remplaçant l'UUID) :

```sql
insert into admins (user_id) values ('COLLE-ICI-L-UUID');
```

Ce compte a maintenant les droits pour valider/refuser des défis,
forcer un tirage au sort, et supprimer des défis.

## 3. Configurer le projet en local

Il te faut [Node.js](https://nodejs.org) installé sur ton ordinateur.

```bash
npm install
cp .env.example .env
```

Ouvre `.env` et vérifie que `VITE_SUPABASE_URL` et
`VITE_SUPABASE_ANON_KEY` correspondent bien à ton projet Supabase
(Project Settings → API Keys → "Clé publiable").

```bash
npm run dev
```

Ouvre l'adresse affichée (en général `http://localhost:5173`) pour
tester le site en local avant de le mettre en ligne.

## 4. Mettre le code sur GitHub

```bash
git init
git add .
git commit -m "Sprintly - premier commit"
```

Puis crée un nouveau dépôt sur https://github.com/new (ne coche aucune
case d'initialisation), et suis les commandes qu'il t'affiche pour
pousser ce dossier dessus (`git remote add origin ...`, `git push`).

⚠️ Le fichier `.env` n'est jamais poussé sur GitHub (il est dans
`.gitignore`) — c'est normal et voulu, il contient une clé même si elle
est publique.

## 5. Déployer sur Vercel (gratuit)

1. Va sur https://vercel.com → connecte-toi avec GitHub
2. **Add New** → **Project** → sélectionne ton dépôt `sprintly`
3. Dans **Environment Variables**, ajoute :
   - `VITE_SUPABASE_URL` → (ton URL Supabase)
   - `VITE_SUPABASE_ANON_KEY` → (ta clé publiable Supabase)
4. Clique **Deploy**

Après 1-2 minutes, ton site est en ligne avec une vraie adresse
(`ton-projet.vercel.app`). Chaque fois que tu pousses du code sur
GitHub, Vercel republie automatiquement le site.

---

## Comment fonctionne la sécurité

- Personne ne peut modifier la base de données directement depuis le
  navigateur : toutes les actions (rejoindre un défi, voter, tirer au
  sort, valider...) passent par des fonctions vérifiées côté serveur
  Supabase, qui appliquent les règles (un seul vote par personne, pas de
  vote sur son propre duel, etc.).
- Seul un compte marqué dans la table `admins` peut valider/refuser des
  défis ou en supprimer.
- Il n'y a pas de compte "utilisateur" classique (email/mot de passe)
  pour les participants — comme dans la maquette d'origine, l'identité
  repose sur un pseudo libre. N'importe qui peut donc théoriquement
  participer sous le pseudo de quelqu'un d'autre. Si ça devient un
  problème avec du vrai trafic, la prochaine étape logique est d'ajouter
  une vraie connexion (email/magic link) pour les participants aussi —
  fais-le moi savoir, c'est un ajout raisonnable une fois le site lancé.

## Limite connue du plan gratuit Supabase

Si le site ne reçoit aucune visite pendant 7 jours, le projet Supabase
se met en pause automatiquement (aucune perte de données, il suffit de
cliquer sur "Restore" dans le dashboard Supabase pour le relancer).
